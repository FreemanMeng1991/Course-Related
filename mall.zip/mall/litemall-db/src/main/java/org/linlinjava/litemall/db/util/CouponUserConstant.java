package org.linlinjava.litemall.db.util;

public class CouponUserConstant {
    public static final Short STATUS_USABLE = 0;
    public static final Short STATUS_USED = 1;
    public static final Short STATUS_EXPIRED = 2;
    public static final Short STATUS_OUT = 3;
}
